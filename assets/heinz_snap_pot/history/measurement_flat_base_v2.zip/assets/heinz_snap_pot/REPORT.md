# Heinz Snap Pot — approximate measurement revision

**Geometry and simulation import pass; physical accuracy remains unverified.**
The user supplied approximate dimensions: outer lid 95 x 74 mm, upper body
80 x 55 mm, base 68 x 48 mm, total height 63–64 mm, and a flat top assembly
about 2.5 mm thick. These replace the earlier cloud-only size estimates.
The previous assets and source are in `history/point_cloud_only_v1.zip`.

These are nominal anchors, not certified ruler ground truth. Height is the
reported range's 63.5 mm midpoint. All three original metric clouds were compared
at their original scale. Their height agrees, but their lateral dimensions do
not jointly agree with the new readings. Neither the cloud nor the entire model
is globally scaled to hide this disagreement.

Final untrimmed symmetric Chamfer: **4.684 mm mean,
12.725 mm P95**. This does not establish ±2 mm object accuracy.

## Dimensions (mm)

| Dimension | Approximate user value | Exported mesh | Difference | Independent accuracy |
|---|---:|---:|---:|---|
| height_mm | 63.50 | 63.50 | +0.00000 | APPROXIMATE_ONLY |
| body_top_long_mm | 80.00 | 80.00 | -0.00000 | APPROXIMATE_ONLY |
| body_top_short_mm | 55.00 | 55.00 | -0.00000 | APPROXIMATE_ONLY |
| rim_long_mm | 95.00 | 95.00 | -0.00000 | APPROXIMATE_ONLY |
| rim_short_mm | 74.00 | 74.00 | +0.00000 | APPROXIMATE_ONLY |
| base_long_mm | 68.00 | 68.00 | +0.00000 | APPROXIMATE_ONLY |
| base_short_mm | 48.00 | 48.00 | +0.00000 | APPROXIMATE_ONLY |
| top_assembly_thickness_mm | 2.50 | 2.50 | +0.00000 | APPROXIMATE_ONLY |

Every export matches its nominal input within ±2 mm. Exact reproduction of
approximate readings is not independent validation; measurement uncertainty was
not supplied. **Top assembly thickness is 2.50 mm total**:
2.35 mm rim/plastic proxy plus an assumed 0.15 mm film.
The film inset remains 1.00 mm. The cloud and photographs support
a flat wider cap, but ±3–5 mm depth noise cannot independently verify a 2.5 mm
plate or the film thickness.

Base/body-top/rim corner radii: 8.73/
13.75/14.80 mm.
Rounding and pose are regularized from the exterior cloud; physical dimensions
are held nominal. Corner metrology remains uncertain under lateral disagreement.

## Comparison with raw clouds

Unconstrained exterior fits to the source clouds give these diagnostic dimensions:

| Source | Height | Upper body L x S | Base L x S | Rim L x S |
|---|---:|---:|---:|---:|
| beans_fuse_K_depth | 65.22 | 60.86 x 43.84 | 44.37 x 26.11 | 66.19 x 46.24 |
| beans_fuse_K | 64.04 | 73.11 x 55.43 | 56.10 x 39.86 | 78.40 x 57.43 |
| beans_fuse_none | 65.41 | 65.57 x 56.34 | 51.10 x 40.35 | 72.82 x 58.90 |

Height agreement with 63–64 mm and lateral disagreement argue against a single
global scale correction. Missing rim coverage, pose/fusion distortion and rough
measurement uncertainty remain possible contributors; a unique cause is not
established. The prior K+depth choice was based on per-view scale consistency,
which did not prove lateral accuracy.

Selected source: **`Gitignore-but-important/recon/beans_fuse_K/object.ply`**, 4,089 points.
SHA256: `872e820278111262ceb89276a9bcd33db841a4f4b66e3bed8b38a767c013fda3`.
This source has the lowest full symmetric mean for the new nominal dimensions.
All candidates come from one capture and are not independent validation.
The nonmetric `beans_global40` is excluded.

Pose refinement permits only XY translation and yaw; z=0 and scale=1 stay fixed.
The fit uses a 4 mm band inside 5 mm horizontal slice envelopes to suppress
interior ghost sheets. Regularization prevents physical-size disagreement from
creating extreme rounding or moving the model to match only one side.
**Every original point is retained in the final distances and renders.**

## Three comparisons in this revision

| Candidate | Unscaled metric cloud | Symmetric mean mm | Symmetric P95 mm | Selection |
|---|---|---:|---:|---|
| 1 | beans_fuse_K_depth | 9.083 | 18.203 |  |
| 2 | beans_fuse_K | 4.684 | 12.725 | selected |
| 3 | beans_fuse_none | 5.915 | 15.785 |  |

Each candidate used identical nominal physical dimensions, with its own rigid
pose and regularized rounding fit. The selected geometry was re-exported for
renders without a fourth geometry candidate. Earlier cloud-only rounds are archived.

## Distances and regions above 5 mm

Cloud→mesh uses exact closest points on the exported triangles for all raw
points. Mesh→cloud uses 200,000 area-uniform exterior samples (seed 20261014)
and nearest raw points. Distances are unsquared Euclidean millimetres. Symmetric
mean and P95 give 0.5 weight to each direction, independent of sample count.
Reverse distances include errors due to missing coverage.

| Direction | Mean mm | P95 mm | Fraction >5 mm |
|---|---:|---:|---:|
| cloud_to_mesh | 4.738 | 15.639 | 34.7% |
| mesh_to_cloud | 4.630 | 10.387 | 40.1% |
| Equal-direction symmetric | 4.684 | 12.725 | — |

Raw points grouped by nearest model region:

| Region | Points | Mean mm | P95 mm | Points >5 mm |
|---|---:|---:|---:|---:|
| base | 70 | 8.401 | 14.700 | 67 |
| body | 2537 | 4.597 | 15.225 | 826 |
| rim_or_lid | 1482 | 4.806 | 16.909 | 527 |

- **Body/interior:** 1420 points lie >5 mm inside the model. This includes physical-size disagreement as well as visible ghost sheets; not all such errors can be dismissed as noise.
- **Outer scan regions:** 0 points lie >5 mm outside. Their exact coordinates and nearest regions are retained in `cloud_residuals.csv`.
- **Lid perimeter:** the 95 x 74 mm cap extends beyond the raw-cloud supports. Reverse distances along this overhang are large; the scan does not verify its size.
- **Base/lower sides:** the lowest raw z is 4.930 mm. Base-only reverse distance is 8.544 mm mean / 14.357 mm P95. The flat underside remains an assumption.

For context, reverse distance excluding the base is
4.115 mm mean /
9.332 mm P95. It does not replace the full metric.

## Files, coordinates and simulation

- `visual.glb`: one closed exterior, 1200 triangles, photo-derived white/teal/orange palette.
- `collision.obj`: two named closed convex solids (body and top assembly), preserving the flange overhang.
- `snap_pot.blend`: native scene, named dimension properties, packed texture, four cameras and raw reference cloud.
- `parameters.json` / `measurements_approx.json`: editable model and exact provenance of approximate readings.
- `comparison_4views.png`, `renders/`, `cameras.json`: four matched-camera pairs at identical scale.
- `verification.json`, `dimensions.csv`, `verification_rounds/`, `selection.json`: current checks and candidate comparisons.
- `cloud_residuals.csv`, `residuals_over_5mm.ply`, `residual_map.png`: every point's error; red PLY points exceed 5 mm.
- `measurement_candidates/`: each comparison's parameters, exports and logs.

Units are **metres**, +Z up, +X along the long side. Origin is the flat base centre
at z=0; import scale is `[1,1,1]`. Blender uses `export_yup=False`; generic glTF
viewers assuming Y-up may display this intentionally Z-up asset sideways.
All meshes have positive volume, consistent winding and closed topology;
collision parts are individually convex. The cap collision replaces the film's
inset step with a bevel within the film's 0.15 mm thickness.

ManiSkill CPU import and 4 cm drop: **PASS**.
Loaded shapes: 2; cooked vertex counts:
[27, 39]; maximum cooked bound error:
0.000004 mm. Cooking can simplify local curvature.
Mass/friction are **test-only 0.2 kg/0.5**. Inertia is a uniform filled-envelope
proxy. Blender checks visuals; the CPU test disables Vulkan visual loading.
Panda grasp, approach clearance, stiffness, lid peeling and force calibration
remain untested.

For an **80 mm Panda opening**, nominal lid short-side clearance is
**6.0 mm total**; its 95 mm long dimension exceeds the opening.
The body just below the lid offers **25.0 mm total**
short-side clearance. The 80 mm body long side has zero nominal clearance.
These dimensions do not certify a grasp or a collision-free approach.

## Assumptions and remaining uncertainty

- User dimensions are approximate nominal anchors, not certified ruler ground truth; their uncertainty was not supplied.
- Total height is 63.5 mm, the midpoint of the reported 63-64 mm range.
- The 2.5 mm flat top assembly includes rim plastic and film; it does not mean 2.5 mm film.
- Film thickness 0.15 mm and film inset 1.0 mm remain unresolved appearance/geometry assumptions; rim plastic is derived as 2.35 mm.
- Flat base at z=0; no underside recess, hidden cavity, contents, ribs, or unseen tab geometry.
- Centered rounded-rectangle sections taper linearly from the stated upper body to base dimensions.
- Corners use a regularized exterior-cloud estimate; lateral size disagreement prevents reliable corner metrology.
- Raw cloud is rigidly aligned in XY/yaw only; no isotropic or anisotropic rescaling, Z offset, cropping or residual trimming.
- Significant lateral disagreement with raw fused depth remains; repeated internal surfaces and incomplete coverage do not fully explain physical scale.
- Nominal dimensions are retained instead of shrinking to incompatible depth; actual dimensions may differ from these approximate readings.

The same 40-frame orbit capture supplies appearance. Six original frames are
in `source_views.jpg`; colours are sampled from frame 0037. Lettering and detailed
artwork are not recreated, and illumination-independent reflectance is unmeasured.

![Matched camera comparisons](comparison_4views.png)

![All raw residuals](residual_map.png)
