# Heinz Snap Pot: generated asset and verification

**Status: usable rigid simulation proxy; metric accuracy is NOT independently verified.**
Three fitting/verification rounds were completed. Round 2 is selected: it has the
lowest raw symmetric mean, improved rim coverage, and stable body dimensions.
The original ruler tolerance cannot be certified: the ruler fields were blank and
the user explicitly authorized extracting dimensions from the point cloud instead.
No estimate below is relabeled as a ruler measurement.

The complete raw-cloud symmetric Chamfer is **3.045 mm mean,
12.031 mm P95**. The raw P95 does not meet a 5 mm target.
The source contains duplicate interior sheets and lacks the base surface. These
limitations remain visible in the saved comparison images and residual files.

## Deliverables and coordinates

- `visual.glb`: closed, connected exterior, 1200 triangles; white plastic and photo-sampled teal/orange lid palette.
- `collision.obj`: **two named closed convex solids**, body and rim/lid cap; analytic decomposition, not a single hull bridging the flange overhang.
- `snap_pot.blend`: native Blender scene, named dimension properties on the scene, packed texture, comparison cameras and raw point cloud.
- `parameters.json`: all physical dimensions, corner radii, thickness assumptions, source hash and cloud-to-model transform.
- `comparison_4views.png`, `renders/`, `cameras.json`: four matched orthographic cameras, identical pose/scale for model and all raw points.
- `verification.json`, `dimensions.csv`, `verification_rounds/`: exported mesh QA and three recorded candidates.
- `cloud_residuals.csv`, `residuals_over_5mm.ply`, `residual_map.png`: every source point and its exact residual; red PLY points exceed 5 mm.
- `maniskill_smoke.json`: actual CPU collision loading and drop-test result.

All mesh vertex coordinates are **metres**, +X is the long axis, +Z is up;
the origin is the centre of the flat base at z=0. Import with scale `[1,1,1]`
and no axis correction. The GLB deliberately disables Blender's usual Y-up export
conversion (`export_yup=False`), to satisfy this asset's Z-up convention.
See [Blender export API](https://docs.blender.org/api/5.0/bpy.ops.export_scene.html).
Some generic glTF viewers assume Y-up and may display this explicitly Z-up asset sideways.

## Dimensions (mm)

"Body top" means the body immediately below the flange. "Rim" is its outer
footprint. Height includes the assumed film thickness. Error below measures
export reproduction only, not physical-object accuracy.

| Dimension | Cloud fit | Exported mesh | Export minus fit | Ruler | Ruler ±2 mm |
|---|---:|---:|---:|---|---|
| height_mm | 65.22 | 65.22 | +0.00000 | unavailable | UNVERIFIED |
| body_top_long_mm | 60.86 | 60.86 | +0.00000 | unavailable | UNVERIFIED |
| body_top_short_mm | 43.84 | 43.84 | +0.00000 | unavailable | UNVERIFIED |
| rim_long_mm | 66.19 | 66.19 | +0.00000 | unavailable | UNVERIFIED |
| rim_short_mm | 46.24 | 46.24 | -0.00000 | unavailable | UNVERIFIED |
| base_long_mm | 44.37 | 44.37 | +0.00000 | unavailable | UNVERIFIED |
| base_short_mm | 26.11 | 26.11 | +0.00000 | unavailable | UNVERIFIED |

Body top/base corner radii: 11.95/4.89 mm.
Rim radius: 13.14 mm. Rim thickness **1.2 mm**, film
thickness **0.15 mm**, and film inset **1.0 mm** are explicit unresolved assumptions.
Bootstrap intervals in `parameters.json` measure sampling stability only; they
exclude calibration/pose errors and cannot establish ±2 mm accuracy.

## Inputs and fitting

Selected cloud: `Gitignore-but-important/recon/beans_fuse_K_depth/object.ply` (3,560 points). SHA256:
`0e737d011c21918e35f8da99fcd56633d4790d1e556bfb9e2d1847e589c46a4c`.
This is the metric RealSense TSDF reconstruction with both intrinsics and depth
conditioning. All 40 per-view metric scale ratios are finite; p10–p90 is
0.50418–0.51026. The cloud is never rescaled. Alignment is only a Z rotation and
XY translation; table z=0 remains fixed. The transform is recorded in the JSON.

The repo contains a 40-frame orbit capture, rather than a separately identified
six-photo attachment set. Six representative original frames are shown in
`source_views.jpg`. Colours are sampled from frame 0037; the label is simplified
to its observed white/teal/orange regions. Printed text, artwork details, specular
glare and illumination-independent material colour are not reconstructed.

The fit uses 5 mm horizontal slices, a 4 mm band inside each
slice's convex envelope, and a Cauchy robust loss. This avoids copying ghost
surfaces into the body. **No point is removed from verification or renders.**
Top plane height uses central high points; the rim uses 2.5/97.5-percentile supports.
At least 1 mm per side of flange overhang is imposed where sparse samples cannot
separate the rim from the body; this is an additional model constraint, not a measurement.

The alternative reconstructions disagree substantially:

| Reconstruction | Height mm | Rim L x S mm | Base L x S mm |
|---|---:|---:|---:|
| beans_fuse_K_depth | 65.22 | 66.19 x 46.24 | 44.37 x 26.11 |
| beans_fuse_K | 64.04 | 78.40 x 57.43 | 56.10 x 39.86 |
| beans_fuse_none | 65.41 | 72.82 x 58.90 | 51.10 x 40.35 |

These are alternative fits of the same capture, not independent measurements.
Their 11–13 mm lateral disagreements show that the stated ±3–5 mm unbiased-noise
assumption is not established for these fused files. K+depth was selected for
depth-constrained poses and the most consistent per-view scale; that choice is
not proof of absolute accuracy. `beans_global40` was excluded because its source
is Pi3X reconstruction units, not the measured-depth metric TSDF.

## Chamfer definition and untrimmed results

Distances are unsquared Euclidean millimetres. Cloud-to-mesh uses exact closest
points on exported triangles, for every original cloud point. Mesh-to-cloud
uses 200,000 area-uniform exterior mesh samples (seed 20261014) and nearest
original points. The symmetric mean is the average of the two directional means;
P95 is the quantile of their equally weighted (0.5/0.5) distributions, so unequal
sample counts do not bias the metric toward the dense mesh sample set. Surface
sampling and source-cloud coverage still limit the reverse estimate.

| Direction | Mean mm | P95 mm | Fraction >5 mm |
|---|---:|---:|---:|
| All cloud → mesh | 3.682 | 14.118 | 22.7% |
| Full exterior mesh → cloud | 2.408 | 7.998 | 10.6% |
| Equal-direction symmetric | 3.045 | 12.031 | — |

Raw cloud points, grouped by their nearest mesh region:

| Region | Points | Mean mm | P95 mm | Points >5 mm |
|---|---:|---:|---:|---:|
| base | 30 | 10.931 | 13.354 | 30 |
| body | 2900 | 3.679 | 14.498 | 645 |
| rim_or_lid | 630 | 3.349 | 12.800 | 132 |

**Regions above 5 mm:** 794 raw points are more than 5 mm
inside the model. The XY/XZ slice map shows repeated internal sheets; they are
consistent with fusion/registration artifacts, not evidence for hidden geometry.
Another 13 points lie more than 5 mm outside the model,
around sparse/distorted outer regions. Per-point coordinates and nearest-region
labels are in the CSV; this classification does not claim to prove the true
surface location.

The entire unobserved flat base is >5 mm from available cloud samples:
base-only mesh→cloud mean **8.572 mm**, P95
**10.877 mm**. Minimum observed z is
**5.752 mm**. Lowest sidewall and top-edge coverage gaps
also contribute. For context only, mesh→cloud **excluding the base** is
1.907 mm mean / 4.280 mm P95.
This coverage-limited number does not replace the full metric above.

## Three rounds

| Round | Fit envelope band mm | Rim percentile | Symmetric mean mm | Symmetric P95 mm | Structural checks |
|---|---:|---:|---:|---:|---|
| 1 | 4 | 95.0 | 3.047 | 12.031 | True |
| 2 | 4 | 97.5 | 3.045 | 12.031 | True |
| 3 | 3 | 97.5 | 3.114 | 12.201 | True |

Round 1 established the body and exposed sparse rim support. Round 2 expanded
rim support and reduced external outliers. Round 3 tightened the fitting band
as a sensitivity check: body dimensions changed <1 mm but the full metric got
slightly worse. The selected round 2 was re-exported for final renders; this is
not a fourth geometry-fit candidate. Further deformation to fit interior ghosts
would conflict with the requested clean outer shape.

## Simulation checks and limits

Visual and collision meshes have consistent winding, positive volume and closed
topology. GLB material/UV/normal seam vertices are welded by equal position for
topology checks. OBJ parts are individually convex; Blender meters and exported
bounds agree to floating-point precision. The collision lid cap replaces the
film's 1 mm inset step with a convex bevel over its 0.15 mm height.

ManiSkill CPU collision import + 4 cm drop: **PASS**.
See `maniskill_smoke.json` for measured shape count, final pose/velocity, and test
parameters. This uses a **test-only 0.2 kg mass and 0.5 friction**, with uniform
filled-envelope inertia. These values were not measured. The headless test does
not load a Vulkan visual component; Blender and the GLB parser check visuals.
No Panda grasp trial or force calibration was performed.

PhysX cooked the two shapes to [26, 34] vertices;
their overall bounds differ from the asset parameters by
0.000003 mm. Local curved faces may
be simplified by cooking even though bounding dimensions are retained.

At the nominal rim, an 80 mm opening has **33.76 mm short-axis clearance**
and **13.81 mm long-axis clearance**. These are geometric
differences, not a successful grasp or collision-free approach guarantee.
`recon/snap_pot/maniskill_asset.py` loads existing convex pieces without an
additional decomposition; its `mass_kg` and `friction` arguments are required.
See [SAPIEN builder API](https://sapien-sim.github.io/docs/_modules/sapien/wrapper/actor_builder.html).

## Assumptions and unverified properties

- User authorized dimensions estimated from point cloud; ruler values unavailable.
- Selected beans_fuse_K_depth: metric RealSense TSDF, intrinsics and depth conditioned poses.
- Base is flat at table z=0; footprint extrapolated through missing lowest depth samples.
- Body cross sections are centered rounded rectangles, with linearly varying dimensions and radius.
- Lid is planar; scan curvature is not reproduced as physical film geometry.
- Rim thickness 1.2 mm, film thickness 0.15 mm, film inset 1.0 mm are unresolved modeling assumptions.
- No interior cavity, contents, bottom recess, ribs, or unobserved pull-tab geometry modeled.
- Closed outer envelope used for rigid collision; it does not describe plastic wall thickness.
- Rim outline estimated from 2.5th/97.5th support percentiles of top points; edge is sparsely observed.
- Duplicate interior sheets observed in scan; fit uses outer slice envelopes, but verification uses ALL original points.
- Bootstrap intervals describe sampling stability only, not metric accuracy or correlated scan bias.
- Symmetric centered section profiles and minimum 1 mm-per-side flange overhang are modeling constraints.
- Ruler-grounded accuracy, physical mass/centre of mass/inertia, friction, stiffness, film peeling and grasp success are unverified.
- Replacing ghost-contaminated fused depth or adding independent dimensions is required to certify physical accuracy.

![Four matched camera pairs](comparison_4views.png)

![Untrimmed residual map](residual_map.png)
