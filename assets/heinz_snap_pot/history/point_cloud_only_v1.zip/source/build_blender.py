"""blender --background --python build_blender.py -- --config ... --out ...

Build one closed exterior and an analytic two-piece convex decomposition.
No booleans, decimation, scale transforms, invented cavity, or hidden recesses.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector


def ring(length, width, radius, z, segments):
    if not 0 < radius <= min(length, width)/2:
        raise ValueError('Invalid rounded-rectangle corner radius')
    points = []
    for cx,cy,angle in [(length/2-radius,width/2-radius,0),
                        (-length/2+radius,width/2-radius,90),
                        (-length/2+radius,-width/2+radius,180),
                        (length/2-radius,-width/2+radius,270)]:
        for k in range(segments+1):
            a=math.radians(angle+90*k/segments)
            points.append((cx+radius*math.cos(a), cy+radius*math.sin(a), z))
    return points


def loft(name, profiles, segments):
    vertices=[v for p in profiles for v in ring(*p,segments)]
    n=4*(segments+1)
    faces=[]
    bands=[]
    for layer in range(len(profiles)-1):
        for i in range(n):
            j=(i+1)%n
            a,b,c,d=layer*n+i,layer*n+j,(layer+1)*n+j,(layer+1)*n+i
            faces.extend([(a,b,c),(a,c,d)])
            bands.extend([layer,layer])
    # Triangular fans, with outward winding and no nonplanar n-gons.
    bottom=len(vertices);vertices.append((0,0,profiles[0][3]))
    top=len(vertices);vertices.append((0,0,profiles[-1][3]))
    offset=(len(profiles)-1)*n
    for i in range(n):
        j=(i+1)%n
        faces.extend([(bottom,j,i),(top,offset+i,offset+j)])
        bands.extend([-1,len(profiles)-1])
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(vertices,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.collection.objects.link(obj)
    return obj,bands


def srgb_channel(x):
    return x/12.92 if x <= .04045 else ((x+.055)/1.055)**2.4


def material(name, rgb, roughness, texture=None, emission=False):
    m=bpy.data.materials.new(name);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    color=tuple(srgb_channel(x) for x in rgb)+(1,)
    p.inputs['Base Color'].default_value=color
    p.inputs['Roughness'].default_value=roughness
    if texture:
        t=m.node_tree.nodes.new('ShaderNodeTexImage')
        t.image=bpy.data.images.load(str(texture));t.image.pack()
        m.node_tree.links.new(t.outputs['Color'],p.inputs['Base Color'])
    if emission:
        attr=m.node_tree.nodes.new('ShaderNodeVertexColor');attr.layer_name='cloud_color'
        emit=m.node_tree.nodes.new('ShaderNodeEmission')
        emit.inputs['Strength'].default_value=.25  # cancels +2-stop exposure
        m.node_tree.links.new(attr.outputs['Color'],emit.inputs['Color'])
        m.node_tree.links.new(emit.outputs['Emission'],m.node_tree.nodes.get('Material Output').inputs['Surface'])
    return m


def write_obj(path,objects):
    # Explicit writing preserves metre coordinates and separate OBJ objects.
    offset=1
    with path.open('w') as f:
        f.write('# Units: metres; +Z up; +X long; origin: base centre\n')
        f.write('# Analytic convex decomposition: body and rim/lid cap.\n')
        for obj in objects:
            f.write(f'o {obj.name}\n')
            for v in obj.data.vertices:
                f.write('v '+' '.join(f'{x:.10f}' for x in v.co)+'\n')
            for face in obj.data.polygons:
                f.write('f '+' '.join(str(i+offset) for i in face.vertices)+'\n')
            offset+=len(obj.data.vertices)


def cloud_object(path,radius):
    data=json.loads(path.read_text())
    vertices=[];faces=[];colors=[]
    octa=[(radius,0,0),(-radius,0,0),(0,radius,0),(0,-radius,0),(0,0,radius),(0,0,-radius)]
    tris=[(0,2,4),(2,1,4),(1,3,4),(3,0,4),(2,0,5),(1,2,5),(3,1,5),(0,3,5)]
    for point,color in zip(data['points'],data['colors']):
        offset=len(vertices)
        vertices.extend([tuple(point[j]+o[j] for j in range(3)) for o in octa])
        faces.extend([tuple(offset+i for i in tri) for tri in tris])
        colors.extend([(*color[:3],1)]*6)
    mesh=bpy.data.meshes.new('metric_cloud_points');mesh.from_pydata(vertices,[],faces);mesh.update()
    attr=mesh.color_attributes.new(name='cloud_color',type='FLOAT_COLOR',domain='POINT')
    for x,c in zip(attr.data,colors):
        x.color=tuple(srgb_channel(v) for v in c[:3])+(1,)
    obj=bpy.data.objects.new('reference_point_cloud',mesh);bpy.context.collection.objects.link(obj)
    obj.data.materials.append(material('cloud_colors',(1,1,1),1,emission=True))
    return obj


def render(scene, visual, config, out):
    settings=config['render']
    cloud=cloud_object(out/'aligned_cloud.json',settings['point_radius_mm']/1000)
    scene.render.engine='CYCLES';scene.cycles.device='CPU'
    scene.cycles.samples=settings['samples'];scene.cycles.use_denoising=True
    scene.render.resolution_x=settings['resolution_px'];scene.render.resolution_y=settings['resolution_px']
    scene.render.resolution_percentage=100
    scene.view_settings.view_transform='Standard'
    scene.view_settings.exposure=2.0
    scene.world.use_nodes=True
    scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.7,.7,.7,1)
    scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.35
    bpy.ops.mesh.primitive_plane_add(size=settings['floor_size_m'])
    floor=bpy.context.object;floor.name='render_table_z0'
    floor.data.materials.append(material('render_table',(.53,.55,.57),.8))
    for name,loc,energy,size in [('key',(-.2,-.2,.3),.25,.2),('fill',(.2,.1,.25),.12,.2)]:
        data=bpy.data.lights.new(name,'AREA');data.energy=energy;data.shape='DISK';data.size=size
        obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);obj.location=loc
        obj.rotation_euler=(Vector((0,0,.03))-obj.location).to_track_quat('-Z','Y').to_euler()
    (out/'renders').mkdir(exist_ok=True)
    camera_records=[]
    for name,position in settings['cameras_m'].items():
        data=bpy.data.cameras.new(name);data.type='ORTHO';data.ortho_scale=settings['ortho_scale_m']
        obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);obj.location=position
        obj.rotation_euler=(Vector(settings['target_m'])-obj.location).to_track_quat('-Z','Y').to_euler()
        scene.camera=obj
        bpy.context.view_layer.update()
        camera_records.append(dict(name=name,matrix_world=[list(r) for r in obj.matrix_world],
                                   ortho_scale_m=data.ortho_scale,resolution_px=settings['resolution_px']))
        for mode in ['model','cloud']:
            visual.hide_render=mode=='cloud';cloud.hide_render=mode=='model'
            scene.render.filepath=str(out/'renders'/f'{name}_{mode}.png')
            bpy.ops.render.render(write_still=True)
    (out/'cameras.json').write_text(json.dumps(camera_records,indent=2)+'\n')
    visual.hide_render=False;cloud.hide_render=True;cloud.hide_set(True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);ap.add_argument('--skip-render',action='store_true')
    args=ap.parse_args(sys.argv[sys.argv.index('--')+1:])
    config=json.loads(args.config.read_text());g=config['geometry'];out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
    scene['parameters_json']=json.dumps(config)
    for k,v in g.items():scene[k]=v
    d={k:v/1000 for k,v in g.items() if k.endswith('_mm')}
    h=d['height_mm'];zrim=h-d['lid_thickness_mm'];zbody=zrim-d['rim_thickness_mm']
    base=(d['base_long_mm'],d['base_short_mm'],d['base_corner_radius_mm'],0)
    shoulder=(d['body_top_long_mm'],d['body_top_short_mm'],d['body_top_corner_radius_mm'],zbody)
    rim=(d['rim_long_mm'],d['rim_short_mm'],d['rim_corner_radius_mm'],zbody)
    rim_top=(*rim[:3],zrim)
    inset=d['lid_inset_mm']
    lid_bottom=(rim[0]-2*inset,rim[1]-2*inset,rim[2]-inset,zrim)
    lid_top=(*lid_bottom[:3],h)
    if min(zbody,inset,rim[2]-inset)<=0:raise ValueError('Invalid dimensions')
    visual,bands=loft('heinz_snap_pot_visual',[base,shoulder,rim,rim_top,lid_bottom,lid_top],g['visual_corner_segments'])
    visual.data.materials.append(material('white_plastic',config['appearance']['plastic_srgb'],.38))
    visual.data.materials.append(material('photo_lid',config['appearance']['lid_teal_srgb'],.3,out/'lid_texture.png'))
    uv=visual.data.uv_layers.new(name='LidXY')
    for poly,band in zip(visual.data.polygons,bands):
        poly.material_index=1 if band>=4 else 0
        # Flat per-face normals preserve sharp physical rim transitions.
        for loop_i in poly.loop_indices:
            co=visual.data.vertices[visual.data.loops[loop_i].vertex_index].co
            uv.data[loop_i].uv=(co.x/lid_top[0]+.5,co.y/lid_top[1]+.5)
    visual['up_axis']='Z';visual['units']='metres';visual['dimension_status']=config['status']
    bpy.ops.object.select_all(action='DESELECT');visual.select_set(True);bpy.context.view_layer.objects.active=visual
    bpy.ops.export_scene.gltf(filepath=str(out/'visual.glb'),export_format='GLB',use_selection=True,
                              export_yup=False,export_animations=False,export_extras=True)
    # Convex frustum + convex rim/lid cap. Shared interface only, no volume overlap.
    body,_=loft('body_convex',[base,shoulder],g['collision_corner_segments'])
    cap,_=loft('rim_lid_convex',[rim,rim_top,lid_top],g['collision_corner_segments'])
    write_obj(out/'collision.obj',[body,cap])
    for obj in [body,cap]:obj.hide_render=True;obj.hide_set(True)
    if not args.skip_render:render(scene,visual,config,out)
    bpy.ops.wm.save_as_mainfile(filepath=str(out/'snap_pot.blend'))
    print('SNAP_POT_BUILD_COMPLETE',str(out))


if __name__=='__main__':main()
