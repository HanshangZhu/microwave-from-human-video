"""CPU ManiSkill import/drop smoke test. Not a calibrated Panda grasp test."""
import argparse
import json
from pathlib import Path

import numpy as np
import sapien
from mani_skill.envs.sapien_env import BaseEnv

from maniskill_asset import build_snap_pot


class PotSmokeEnv(BaseEnv):
    SUPPORTED_REWARD_MODES=['none']
    SUPPORTED_ROBOTS=['none']

    def __init__(self,asset_dir,**kw):
        self.asset_dir=asset_dir
        super().__init__(robot_uids='none',obs_mode='none',reward_mode='none',
                         sim_backend='cpu',render_backend='none',**kw)

    @property
    def _default_sensor_configs(self):return []

    @property
    def _default_human_render_camera_configs(self):return []

    def _load_scene(self,options):
        b=self.scene.create_actor_builder()
        b.add_box_collision(half_size=[.2,.2,.01])
        b.initial_pose=sapien.Pose(p=[0,0,-.01]);b.build_static(name='table')
        self.pot=build_snap_pot(self.scene,self.asset_dir,mass_kg=.2,friction=.5,
                               initial_pose=sapien.Pose(p=[0,0,.04]))

    def _initialize_episode(self,env_idx,options):
        self.pot.set_pose(sapien.Pose(p=[0,0,.04]))

    def evaluate(self):return {}

    def _get_obs_extra(self,info):return {}

    def get_state_dict(self):
        # This installed ManiSkill version unconditionally queries an agent in
        # BaseEnv.get_state_dict; an object-only test has no controller state.
        return self.scene.get_sim_state()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--asset',type=Path,required=True);a=ap.parse_args()
    env=PotSmokeEnv(a.asset);env.reset(seed=42)
    body=env.pot._bodies[0]
    shapes=body.get_collision_shapes()
    g=json.loads((a.asset/'parameters.json').read_text())['geometry']
    cooked=np.concatenate([np.asarray(s.vertices)*np.asarray(s.scale) for s in shapes])
    bounds=np.stack([cooked.min(0),cooked.max(0)])*1000
    expected=np.array([[-g['rim_long_mm']/2,-g['rim_short_mm']/2,0],
                        [g['rim_long_mm']/2,g['rim_short_mm']/2,g['height_mm']]])
    bounds_error=float(np.abs(bounds-expected).max())
    history=[]
    for _ in range(100):
        env.step(None)
        history.append(env.pot.pose.p.cpu().numpy()[0].copy())
    positions=np.asarray(history);end=positions[-1]
    velocity=np.asarray(body.linear_velocity)
    report=dict(test='ManiSkill CPU import and 4 cm drop onto table',
        passed=bool(len(shapes)==2 and bounds_error<=2 and abs(body.mass-.2)<1e-6 and np.isfinite(positions).all() and abs(end[2])<.002 and
                    np.linalg.norm(velocity)<.005 and np.linalg.norm(end[:2])<.01),
        collision_shapes=len(shapes),mass_kg=float(body.mass),
        cooked_bounds_mm=bounds.tolist(),cooked_bounds_max_error_mm=bounds_error,
        cooked_shape_vertices=[len(s.vertices) for s in shapes],
        final_base_position_m=end.tolist(),final_linear_velocity_m_s=velocity.tolist(),
        max_final_20_steps_position_range_m=float(np.ptp(positions[-20:],axis=0).max()),
        test_only_assumptions=dict(mass_kg=.2,static_and_dynamic_friction=.5,restitution=0),
        simulation_steps=100*env._sim_steps_per_control,simulation_seconds=100/env._control_freq,
        visual_runtime_loaded=False,panda_grasp_tested=False,
        note='Headless render_backend=none checks actual ManiSkill collision import and dynamics. GLB geometry/materials separately verified and rendered in Blender. Mass, inertia and friction are not measured.')
    (a.asset/'maniskill_smoke.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2));env.close()
    if not report['passed']:raise SystemExit('ManiSkill collision smoke FAILED')


if __name__=='__main__':main()
